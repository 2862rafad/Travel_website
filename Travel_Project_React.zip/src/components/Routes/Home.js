import Navbar from "/src/components/Navbar";
import Hero from "/src/components/Hero";
import Goal from "../Goal";
import Trip from "../Trip";
import Footer from "/src/components/Footer";
function Home() {
  return (
    <>
      <Navbar />
      <Hero
        hcName="hero"
        heroImg="https://images.unsplash.com/photo-1482192505345-5655af888cc4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=928&q=80"
        title=" Start Your Journey History "
        text="Find Your Favourite Places"
        btntext="Set Your Plan"
        url="/"
        btncName="show"
      />
      <Goal />
      <Trip />
      <Footer />
    </>
  );
}
export default Home;
