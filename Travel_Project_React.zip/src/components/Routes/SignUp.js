import "./SignupStyle.css";
const SignUp = () => {
  return (
    <div className="Contact-box">
      <h1>Sign Up Form</h1>
      <form>
        <h4> First Name</h4>
        <input placeholder="FirstName" />
        <h4> Last Name</h4>
        <input placeholder="LastName" />
        <h4>Date Of Birth</h4>
        <input Date =""/>
        <h4>Email</h4>
        <input placeholder="Email" />
        <h4>Password</h4>
        <input placeholder="password" />
        <button>Submit</button>
      </form>
    </div>
  );
};
export default SignUp;