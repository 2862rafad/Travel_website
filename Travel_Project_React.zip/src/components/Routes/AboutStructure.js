import "./AboutStyle.css";
function AboutStructure() {
  return (
    <div className="About-box">
      <div className="About-text">
        <div>
          <h2>History of Our Journey</h2>
          <p>
            The plans for the complex have been attributed to various architects
            of the period, though the chief architect was probably Ustad Aḥmad
            Lahawrī, an Indian of Persian descent. The five principal elements
            of the complex—main gateway, garden, mosque, jawāb and mausoleum
            were conceived and designed as a unified entity according to the
            tenets of Mughal building practice, which allowed no subsequent
            addition or alteration. Building commenced about 1632
          </p>
        </div>
        <div>
          <h2> Our Mission </h2>
          <p>
            Above all, your mission statement is a marketing asset that is meant
            to be clear, concise, and free of fluff. It should clearly outline
            the purpose of your company offering and demonstrate the common
            goals the company is working to achieve. You should also have other
            team members or advisors read the mission statement and make
            adjustments if needed according to their recommendation
          </p>
        </div>
        <div>
          <h2>Our Vission</h2>
          <p>
            The mission to connect people is what makes this statement so
            strong. And, that promise has gone beyond sweetgreen's website and
            walls of its food shops: The team has made strides in the
            communities where it's opened stores as well. Primarily, it provides
            education to young kids on healthy eating, fitness, sustainability,
            and where food comes from.
          </p>
        </div>
      </div>
    </div>
  );
}
export default AboutStructure;
