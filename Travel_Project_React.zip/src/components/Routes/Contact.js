import Navbar from "/src/components/Navbar";
import Hero from "/src/components/Hero";
import AboutImg from "/src/imgs/t1.jpg";
import Footer from "../Footer";
import ContactForm from "./ContactForm";
function Contact() {
  return (
    <>
      <Navbar />
      <Hero cName="hero-mid" heroImg={AboutImg} title="Know about us" />
      <ContactForm />
      <Footer />
    </>
  );
}
export default Contact;
