import "./ContactFormStyle.css";
const ContactForm = () => {
  return (
    <div className="Contact-box">
      <h1>Leave a message to us</h1>
      <form>
        <input placeholder="Name" />
        <input placeholder="Email" />
        <input placeholder="Subject" />
        <textarea placeholder="Message" rows="4"></textarea>
        <button>Submit</button>
      </form>
    </div>
  );
};
export default ContactForm;
