import Navbar from "/src/components/Navbar";
import Hero from "/src/components/Hero";
import AboutImg from "/src/imgs/t5.jpg";
import Footer from "../Footer";
import AboutStructure from "./AboutStructure";
function About() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        heroImg={AboutImg}
        title="Journey Is always Cool"
      />
      <AboutStructure />
      <Footer />
    </>
  );
}
export default About;
