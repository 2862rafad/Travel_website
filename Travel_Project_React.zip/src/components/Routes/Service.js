import Navbar from "/src/components/Navbar";
import Hero from "/src/components/Hero";
import AboutImg from "/src/imgs/t7.jpg";
import Footer from "../Footer";
import Trip from "../Trip";
function Service() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        heroImg={AboutImg}
        title="Know about our service"
      />
      <Trip />
      <Footer />
    </>
  );
}
export default Service;
