import Travel1 from "/src/imgs/t3.jpg";
import Travel2 from "/src/imgs/t4.jpg";
import Travel3 from "/src/imgs/t5.jpg";
import Travel4 from "/src/imgs/t6.jpg";
import "./GoalStyle.css";
import { Component } from "react";
class GoalData extends Component {
  render() {
    return (
      <div className={this.props.reverse}>
        <div className="goald_text">
          <h2>{this.props.text}</h2>
          <p>{this.props.text1}</p>
        </div>
        <div className="imgg">
          <img alt="travelImg" src={this.props.image1} />
          <img alt="travelImg" src={this.props.image2} />
        </div>
      </div>
    );
  }
}
export default GoalData;
