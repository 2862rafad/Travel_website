import "./TripStyle.css";
function TripStructure(props) {
  return (
    <div className="trip-box">
      <div className="image-add">
        <img alt="TripImage" src={props.image1} />
      </div>
      <h4>{props.heading}</h4>
      <p>{props.text} </p>
    </div>
  );
}
export default TripStructure;
