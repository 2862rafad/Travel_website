import "./TripStyle.css";
import Travel5 from "/src/imgs/t2.jpg";
import Travel6 from "/src/imgs/t8.jpg";
import Travel7 from "/src/imgs/t9.jpg";
import TripStructure from "./TripStructure";

function Trip() {
  return (
    <div className="trip-heading">
      <h2> Recent Trip Pictures </h2>
      <p>Tremendous Historical Locations</p>
      <div className="trip-box2">
        <TripStructure
          image1={Travel5}
          heading="Top Places "
          text="location of a significant event, a prehistoric or historic 
  occupation or activity, or a building or structure, whether standing, ruined, 
  or vanished, where the location itself possesses historic, 
  cultural, or archeological value regardless of the value of 
  any existing structure"
        />
        <TripStructure
          image1={Travel6}
          heading="Top Places "
          text="location of a significant event, a prehistoric or historic 
  occupation or activity, or a building or structure, whether standing, ruined, 
  or vanished, where the location itself possesses historic, 
  cultural, or archeological value regardless of the value of 
  any existing structure"
        />
        <TripStructure
          image1={Travel7}
          heading="Top Places "
          text="location of a significant event, a prehistoric or historic 
  occupation or activity, or a building or structure, whether standing, ruined, 
  or vanished, where the location itself possesses historic, 
  cultural, or archeological value regardless of the value of 
  any existing structure"
        />
      </div>
    </div>
  );
}
export default Trip;
