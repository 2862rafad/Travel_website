import Travel1 from "/src/imgs/t3.jpg";
import Travel2 from "/src/imgs/t4.jpg";
import Travel3 from "/src/imgs/t5.jpg";
import Travel4 from "/src/imgs/t6.jpg";
import "./GoalStyle.css";
import GoalData from "./GoalData";

const Goal = () => {
  return (
    <div className="goald">
      <h1>Most visited Places</h1>
      <p>Tour is always a new option to see something new</p>
      <GoalData
        reverse="goald_first"
        text="The most Beautiful Places"
        text1="The cathedral of Tours, dedicated to Saint Gatien
     its canonized first bishop,was begun about 1170 to replace 
     the cathedral that was burnt out in 1166 during the dispute between 
     Louis VII of France and Henry II of England.
     The lowermost stages of the western towers belong to the 12th century"
        image1={Travel1}
        image2={Travel2}
      />

      <GoalData
        reverse="goald_first-reverse"
        text="The most Beautiful Places"
        text1="The cathedral of Tours, dedicated to Saint Gatien
     its canonized first bishop,was begun about 1170 to replace 
     the cathedral that was burnt out in 1166 during the dispute between 
     Louis VII of France and Henry II of England.
     The lowermost stages of the western towers belong to the 12th century"
        image1={Travel3}
        image2={Travel4}
      />
    </div>
  );
};
export default Goal;
